<html>
</style>
<title>Gse7en_Z-h</title>
<link href='http://res7ock.org/assets/img/favicon.png' rel='shortcut icon' alt='icon'>
<head>
<style>
                @import "http://fonts.googleapis.com/css?family=Play:400,700";
                        .rainbow {
 
                            -webkit-background-clip: text;
                            -background-clip: text;
                            -webkit-text-fill-color: transparent;
                            -text-fill-color: transparent;
                            background-image: -webkit-gradient( linear, left top, right top, color-stop(0, #f22), color-stop(0.15, #f2f), color-stop(0.3, #66f), color-stop(0.45, #2ff), color-stop(0.6, #2f2),color-stop(0.75, #2f2), color-stop(0.9, #ff2), color-stop(1, #f22) );
                            background-image: gradient( linear, left top, right top, color-stop(0, #f22), color-stop(0.15, #f2f), color-stop(0.3, #66f), color-stop(0.45, #2ff), color-stop(0.6, #2f2),color-stop(0.75, #2f2), color-stop(0.9, #ff2), color-stop(1, #f22) );
                            }
                        .text-glow:hover, .text-glow:focus, .text-glow:active {
                           -webkit-stroke-width: 5.3px;
                           -webkit-stroke-color: #ccdddd;
                           -webkit-fill-color: #eeeeee;
                           text-shadow: 1px 0px 20px silver;
                           -webkit-transition: width 0.3s; /*Safari & Chrome*/
                           transition: width 0.3s;
                           -moz-transition: width 0.3s; /* Firefox 4 */
                           -o-transition: width 0.3s; /* Opera */
                           }
                       .text-glow a {
                           -webkit-transition: all 0.3s ease-in; /*Safari & Chrome*/
                           transition: all 0.3s ease-in;
                           -moz-transition: all 0.3s ease-in; /* Firefox 4 */
                           -o-transition: all 0.3s ease-in; /* Opera */
                           text-decoration:none;
                           color:white;
                       }
                        body {
                                background:    #000000;
                                line-height: 1;
                                color: #bbb;
                                font-family: "CONSOLAS";
                                font-size: 12px;
                                background:#121214 url(bg.jpg) no-repeat center center fixed;
                                  -webkit-background-size: cover;
                                  -moz-background-size: cover;
                                  -o-background-size: cover;
                                  background-size: cover;
 
                        }
                        textarea, input, select {
                                border:0;
                                BORDER-COLLAPSE:collapse;
                                border:double 2px #696969;
                                color:#fff;
                                background:#000000;
                                margin:0;
                                padding:2px 4px;
                                font-family: Lucida Console,Tahoma;
                                font-size:12px;
                                box-shadow: 0 0 15px gray;
                                -webkit-box-shadow: 0 0 15px gray;
                                -moz-box-shadow: 0 0 15px blue;
                        }                      
        </style>
<center>
    <hr />
<h1>Zone-H Mass Deface Notify</h1>
<hr />
    <form method=POST>
    <form action="" method="post">
<input type="text" name="defacer" size="56" value="Gse7en" />
<br>
<select name="hackmode">
<option>--------SELECT--------</option>
<option value="1">known vulnerability (i.e. unpatched system)</option>
<option value="2" >undisclosed (new) vulnerability</option>
<option value="3" >configuration / admin. mistake</option>
<option value="4" >brute force attack</option>
<option value="5" >social engineering</option>
<option value="6" >Web Server intrusion</option>
<option value="7" >Web Server external module intrusion</option>
<option value="8" >Mail Server intrusion</option>
<option value="9" >FTP Server intrusion</option>
<option value="10" >SSH Server intrusion</option>
<option value="11" >Telnet Server intrusion</option>
<option value="12" >RPC Server intrusion</option>
<option value="13" >Shares misconfiguration</option>
<option value="14" >Other Server intrusion</option>
<option value="15" >SQL Injection</option>
<option value="16" >URL Poisoning</option>
<option value="17" >File Inclusion</option>
<option value="18" >Other Web Application bug</option>
<option value="19" >Remote administrative panel access bruteforcing</option>
<option value="20" >Remote administrative panel access password guessing</option>
<option value="21" >Remote administrative panel access social engineering</option>
<option value="22" >Attack against administrator(password stealing/sniffing)</option>
<option value="23" >Access credentials through Man In the Middle attack</option>
<option value="24" >Remote service password guessing</option>
<option value="25" >Remote service password bruteforce</option>
<option value="26" >Rerouting after attacking the Firewall</option>
<option value="27" >Rerouting after attacking the Router</option>
<option value="28" >DNS attack through social engineering</option>
<option value="29" >DNS attack through cache poisoning</option>
<option value="30" >Not available</option>
</select>
<br>
<select name="reason">
<option style='display:block;width:100%;'>--------SELECT--------</option>
<option value="1" >Heh...just for fun!</option>
<option value="2" >Revenge against that website</option>
<option value="3" >Political reasons</option>
<option value="4" >As a challenge</option>
<option value="5" >I just want to be the best defacer</option>
<option value="6" >Patriotism</option>
<option value="7" >Not available</option>
</select>
<br>
<textarea name="domain" style='display:block;width:25%;height:150px;'>List Of Domains</textarea>
<p>(1 Domain Per Lines)</p>
<input type="submit" value="Send Now !" name="SendNowToZoneH" />
</form></form><span style="color:red">
 
 
   
    <?php
function ZoneH($url, $hacker, $hackmode,$reson, $site )
{
    $k = curl_init();
    curl_setopt($k, CURLOPT_URL, $url);
    curl_setopt($k,CURLOPT_POST,true);
    curl_setopt($k, CURLOPT_POSTFIELDS,"defacer=".$hacker."&domain1=". $site."&hackmode=".$hackmode."&reason=".$reson);
    curl_setopt($k,CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($k, CURLOPT_RETURNTRANSFER, true);
    $kubra = curl_exec($k);
    curl_close($k);
    return $kubra;
}
 
                if($_POST['SendNowToZoneH'])
            {
                ob_start();
                $sub = @get_loaded_extensions();
                if(!in_array("curl", $sub))
                {
                    die('[-] Curl Is Not Supported !! ');
                }
           
                $hacker = $_POST['defacer'];
                $method = $_POST['hackmode'];
                $neden = $_POST['reason'];
                $site = $_POST['domain'];
               
                if ($hacker == "Your Zone-h Name")
                {
                    die ("[-] You Must Fill the Attacker name !");
                }
                elseif($method == "--------SELECT--------")
                {
                    die("[-] You Must Select The Method !");
                }
                elseif($neden == "--------SELECT--------")
                {
                    die("[-] You Must Select The Reason");
                }
                elseif(empty($site))
                {
                    die("[-] You Must Inter the Sites List ! ");
                }
                $i = 0;
                $sites = explode("\n", $site);
                while($i < count($sites))
                {
                    if(substr($sites[$i], 0, 4) != "http")
                    {
                        $sites[$i] = "http://".$sites[$i];
                    }
                    ZoneH("http://zone-h.org/notify/single", $hacker, $method, $neden, $sites[$i]);
                    echo "Site : ".$sites[$i]." Defaced !<br>";
                    ++$i;
                }
                echo "[+] Sending Sites To Zone-H Has Been Completed Successfully !!";
            }
            ?>
            </span>
            </center>
            <br>
<br>
<center><font color="red">Recoded By Gse7en</center>
</html>
